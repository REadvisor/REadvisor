export type Message = {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  isMarkdown?: boolean;
};

export interface UserData {
  name?: string;
  email?: string;
  phone?: string;
  experience?: string;
  isLicensed?: string;
  interestInLicense?: string;
  availability?: string;
  reasonForChange?: string;
  teamNeeds?: string;
  workStyle?: string;
  techComfort?: string;
  strength?: string;
  weakness?: string;
  income?: string;
}

export enum ChatPhase {
  GREETING,
  GET_NAME,
  GET_EMAIL,
  VALIDATE_EMAIL,
  GET_PHONE,
  VALIDATE_PHONE,
  ASSESSMENT_EXPERIENCE,
  ASSESSMENT_LICENSED,
  ASSESSMENT_LICENSE_INTEREST,
  ASSESSMENT_AVAILABILITY,
  ASSESSMENT_REASON,
  ASSESSMENT_TEAM_NEEDS,
  ASSESSMENT_WORKSTYLE,
  ASSESSMENT_TECH_COMFORT,
  ASSESSMENT_STRENGTH,
  ASSESSMENT_WEAKNESS,
  ASSESSMENT_INCOME,
  ANALYZING,
  RECOMMENDATION,
  COMPLETE,
}