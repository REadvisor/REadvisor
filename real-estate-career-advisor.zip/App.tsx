import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Message, UserData, ChatPhase } from './types';

// Helper function to render simple markdown-like text
const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
    const formatText = (txt: string) => {
        return txt
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
            .replace(/\*(.*?)\*/g, '<em>$1</em>') // Italics
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>'); // List items
    };

    return (
        <div className="prose prose-sm max-w-none text-white" dangerouslySetInnerHTML={{ __html: formatText(text) }} />
    );
};


// SVG Icons to avoid extra dependencies
const BotIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7.07 18.28c.43-.9 3.05-1.78 4.93-1.78s4.5.88 4.93 1.78A7.96 7.96 0 0 1 12 20c-1.89 0-3.62-.66-4.93-1.72zM18.36 16.83c-1.43-1.74-4.9-2.33-6.36-2.33s-4.93.59-6.36 2.33A7.96 7.96 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8c0 1.89-.66 3.62-1.72 4.93z" />
        <path d="M12 6c-1.94 0-3.5 1.56-3.5 3.5S10.06 13 12 13s3.5-1.56 3.5-3.5S13.94 6 12 6zm0 5c-.83 0-1.5-.67-1.5-1.5S11.17 8 12 8s1.5.67 1.5 1.5S12.83 11 12 11z" />
    </svg>
);

const SendIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
    </svg>
);


const ChatMessage: React.FC<{ message: Message }> = ({ message }) => {
    const isBot = message.sender === 'bot';
    return (
        <div className={`flex items-start gap-3 my-4 animate-fade-in ${isBot ? 'justify-start' : 'justify-end'}`}>
            {isBot && <BotIcon className="w-8 h-8 text-indigo-300 flex-shrink-0" />}
            <div className={`max-w-md p-4 rounded-2xl ${isBot ? 'bg-indigo-500 text-white rounded-bl-none' : 'bg-slate-700 text-white rounded-br-none'}`}>
                {message.isMarkdown ? <SimpleMarkdown text={message.text} /> : <p>{message.text}</p>}
            </div>
        </div>
    );
};

const UserInput: React.FC<{ onSubmit: (text: string) => void; isLoading: boolean }> = ({ onSubmit, isLoading }) => {
    const [inputValue, setInputValue] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (inputValue.trim() && !isLoading) {
            onSubmit(inputValue.trim());
            setInputValue('');
        }
    };

    return (
        <form onSubmit={handleSubmit} className="p-4 bg-slate-900/80 backdrop-blur-sm border-t border-slate-700">
            <div className="relative">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={isLoading ? 'The Advisor is thinking...' : 'Type your message...'}
                    disabled={isLoading}
                    className="w-full bg-slate-800 border border-slate-600 rounded-full py-3 pl-5 pr-14 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all duration-300"
                />
                <button
                    type="submit"
                    disabled={isLoading}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-indigo-600 text-white hover:bg-indigo-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
                >
                    <SendIcon className="w-5 h-5" />
                </button>
            </div>
        </form>
    );
};


const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [chatPhase, setChatPhase] = useState<ChatPhase>(ChatPhase.GREETING);
    const userDataRef = useRef<UserData>({});
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const aiRef = useRef<GoogleGenAI | null>(null);

    useEffect(() => {
        if (process.env.API_KEY) {
            aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
        }
    }, []);

    const addMessage = useCallback((sender: 'bot' | 'user', text: string, isMarkdown: boolean = false) => {
        setMessages(prev => [...prev, { id: crypto.randomUUID(), sender, text, isMarkdown }]);
    }, []);

    useEffect(() => {
        chatContainerRef.current?.scrollTo({ top: chatContainerRef.current.scrollHeight, behavior: 'smooth' });
    }, [messages]);

    const handleBotTurn = useCallback(async () => {
        setIsLoading(true);
        await new Promise(res => setTimeout(res, 1000)); // Simulate typing

        switch (chatPhase) {
            case ChatPhase.GREETING:
                addMessage('bot', "Hello! I'm your personal real estate career advisor. I'm here to help you find the perfect career path. To start, what's your full name?");
                setChatPhase(ChatPhase.GET_NAME);
                break;
            
            case ChatPhase.GET_EMAIL:
                addMessage('bot', `Nice to meet you, ${userDataRef.current.name}! What's your email address?`);
                break;

            case ChatPhase.VALIDATE_EMAIL: {
                const email = userDataRef.current.email || '';
                if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    addMessage('bot', `Great, ${email}. Now, what's the best phone number to reach you at?`);
                    setChatPhase(ChatPhase.GET_PHONE);
                } else {
                    addMessage('bot', "That doesn't look like a valid email address. Could you please provide a correct email?");
                    setChatPhase(ChatPhase.GET_EMAIL);
                }
                break;
            }
             case ChatPhase.VALIDATE_PHONE: {
                const phone = userDataRef.current.phone || '';
                if (phone.replace(/\D/g, '').length >= 7) {
                    addMessage('bot', "Thanks! I've got your contact info. Now, let's dive into a few questions to understand your career aspirations.\n\nFirst, are you a new or experienced agent? If you have experience, please tell me for how many years.");
                    setChatPhase(ChatPhase.ASSESSMENT_EXPERIENCE);
                } else {
                    addMessage('bot', "That doesn't seem like a valid phone number. Please enter a valid phone number.");
                    setChatPhase(ChatPhase.GET_PHONE);
                }
                break;
            }
            case ChatPhase.ASSESSMENT_LICENSED:
                 addMessage('bot', 'Got it. Do you currently have an active real estate license?');
                 break;

            case ChatPhase.ASSESSMENT_LICENSE_INTEREST:
                addMessage('bot', 'Are you interested in obtaining one?');
                break;

            case ChatPhase.ASSESSMENT_AVAILABILITY:
                addMessage('bot', 'Are you looking for a full time or part time position?');
                break;

            case ChatPhase.ASSESSMENT_REASON:
                addMessage('bot', 'Why are you looking for a new opportunity right now?');
                break;

            case ChatPhase.ASSESSMENT_TEAM_NEEDS:
                addMessage('bot', 'What are the most important things you are looking for in a team? (e.g., leads, coaching, culture, admin support)');
                break;

            case ChatPhase.ASSESSMENT_WORKSTYLE:
                addMessage('bot', 'How would you describe your ideal work style? (e.g., independent, collaborative, structured)');
                break;

            case ChatPhase.ASSESSMENT_TECH_COMFORT:
                addMessage('bot', 'On a scale from 1-10, how comfortable are you with technology?');
                break;
            
            case ChatPhase.ASSESSMENT_STRENGTH:
                addMessage('bot', 'What would you say is your biggest strength?');
                break;

            case ChatPhase.ASSESSMENT_WEAKNESS:
                addMessage('bot', "And what's an area you're looking to improve on?");
                break;
            
            case ChatPhase.ASSESSMENT_INCOME:
                 addMessage('bot', 'Almost done! Finally, what is your desired annual income?');
                break;

            case ChatPhase.ANALYZING:
                if (!aiRef.current) {
                    addMessage('bot', 'Error: Gemini API key not configured.');
                    setIsLoading(false);
                    return;
                }
                
                // Handle unlicensed candidates immediately
                const isUnlicensed = userDataRef.current.isLicensed?.toLowerCase().includes('no');
                const isInterestedInLicense = userDataRef.current.interestInLicense?.toLowerCase().includes('yes');
                const isNotInterestedInLicense = userDataRef.current.interestInLicense?.toLowerCase().includes('no');

                if (isUnlicensed) {
                    if (isInterestedInLicense) {
                        addMessage('bot', 'Great! A Career Consultant will be in touch with the next steps to obtain your license.');
                        setChatPhase(ChatPhase.COMPLETE);
                        setIsLoading(false);
                        return;
                    }
                    if (isNotInterestedInLicense) {
                         addMessage('bot', 'Okay, thank you for your time. A real estate license is a requirement for most agent roles. We wish you the best in your career search.');
                        setChatPhase(ChatPhase.COMPLETE);
                        setIsLoading(false);
                        return;
                    }
                }
                
                addMessage('bot', 'Thank you for sharing. I\'m analyzing your responses to find the best fit for you. One moment...');
                
                try {
                    const prompt = `
                        You are an expert real estate career consultant bot. A candidate has provided the following detailed information:
                        - Name: ${userDataRef.current.name}
                        - Experience: ${userDataRef.current.experience}
                        - Licensed: ${userDataRef.current.isLicensed}
                        - Availability: ${userDataRef.current.availability}
                        - Reason for new opportunity: ${userDataRef.current.reasonForChange}
                        - Looking for in a team: ${userDataRef.current.teamNeeds}
                        - Work Style: ${userDataRef.current.workStyle}
                        - Tech Comfort (1-10): ${userDataRef.current.techComfort}
                        - Strength: ${userDataRef.current.strength}
                        - Weakness: ${userDataRef.current.weakness}
                        - Desired Annual Income: ${userDataRef.current.income}

                        Based on this comprehensive profile, provide a personalized recommendation for one of the following real estate career models:
                        1.  **Solo Agent**: Best for experienced, licensed, self-motivated individuals who are comfortable with technology and want to build their own brand. They need to be strong at lead generation.
                        2.  **Team Member (Buyer or Listing Agent)**: Great for those who thrive in collaborative environments and want leads/support. Good for both new and experienced agents who value coaching, culture, and systems.
                        3.  **Inside Sales Agent (ISA)**: Ideal for people who are great on the phone, enjoy a structured environment, and are strong at lead generation and qualification. Doesn't always require a license immediately.
                        4.  **Salaried Position**: Good for new agents or those seeking stability, often involving roles like transaction coordination, showing assistant, or marketing coordinator. A good fit for part-time candidates or those who are less comfortable with commission-only roles.

                        Your response should:
                        1.  Start by addressing the candidate by name.
                        2.  Clearly state the recommended career model in bold.
                        3.  Provide a 2-3 paragraph explanation of WHY this model is a good fit, directly referencing their provided answers (e.g., "Since you mentioned your strength is X and you're looking for Y in a team...").
                        4.  End with an encouraging closing statement and mention that a Career Consultant will be in touch using their provided contact information.
                        
                        Keep the tone professional, insightful, and encouraging. Format the response using markdown.
                    `;

                    const response = await aiRef.current.models.generateContent({
                        model: 'gemini-2.5-flash',
                        contents: prompt
                    });
                    
                    const recommendationText = response.text;
                    addMessage('bot', recommendationText, true);
                    setChatPhase(ChatPhase.RECOMMENDATION);

                } catch (error) {
                    console.error("Error calling Gemini API:", error);
                    addMessage('bot', "I'm sorry, I encountered an error while analyzing your profile. A Career Consultant will reach out to you directly. Thank you!");
                    setChatPhase(ChatPhase.COMPLETE);
                }
                break;
            case ChatPhase.RECOMMENDATION:
                 addMessage('bot', 'Thank you for your time! This concludes our session. We look forward to speaking with you soon.');
                 setChatPhase(ChatPhase.COMPLETE);
                 break;
        }
        setIsLoading(false);
    }, [chatPhase, addMessage]);

    useEffect(() => {
        if (messages.length === 0 && chatPhase === ChatPhase.GREETING) {
            handleBotTurn();
        } else if (messages.length > 0 && messages[messages.length - 1].sender === 'user') {
            handleBotTurn();
        }
    }, [messages, chatPhase, handleBotTurn]);

    const handleUserSubmit = (text: string) => {
        addMessage('user', text);

        switch (chatPhase) {
            case ChatPhase.GET_NAME:
                userDataRef.current.name = text;
                setChatPhase(ChatPhase.GET_EMAIL);
                break;
            case ChatPhase.GET_EMAIL:
                userDataRef.current.email = text;
                setChatPhase(ChatPhase.VALIDATE_EMAIL);
                break;
            case ChatPhase.GET_PHONE:
                userDataRef.current.phone = text;
                setChatPhase(ChatPhase.VALIDATE_PHONE);
                break;
            case ChatPhase.ASSESSMENT_EXPERIENCE:
                userDataRef.current.experience = text;
                if (text.toLowerCase().includes('new')) {
                    setChatPhase(ChatPhase.ASSESSMENT_LICENSED);
                } else {
                    // Assume experienced agents are licensed
                    userDataRef.current.isLicensed = 'Yes';
                    setChatPhase(ChatPhase.ASSESSMENT_AVAILABILITY);
                }
                break;
            case ChatPhase.ASSESSMENT_LICENSED:
                userDataRef.current.isLicensed = text;
                if (text.toLowerCase().includes('no')) {
                    setChatPhase(ChatPhase.ASSESSMENT_LICENSE_INTEREST);
                } else {
                    setChatPhase(ChatPhase.ASSESSMENT_AVAILABILITY);
                }
                break;
            case ChatPhase.ASSESSMENT_LICENSE_INTEREST:
                userDataRef.current.interestInLicense = text;
                setChatPhase(ChatPhase.ANALYZING);
                break;
            case ChatPhase.ASSESSMENT_AVAILABILITY:
                userDataRef.current.availability = text;
                setChatPhase(ChatPhase.ASSESSMENT_REASON);
                break;
            case ChatPhase.ASSESSMENT_REASON:
                userDataRef.current.reasonForChange = text;
                setChatPhase(ChatPhase.ASSESSMENT_TEAM_NEEDS);
                break;
            case ChatPhase.ASSESSMENT_TEAM_NEEDS:
                userDataRef.current.teamNeeds = text;
                setChatPhase(ChatPhase.ASSESSMENT_WORKSTYLE);
                break;
            case ChatPhase.ASSESSMENT_WORKSTYLE:
                userDataRef.current.workStyle = text;
                setChatPhase(ChatPhase.ASSESSMENT_TECH_COMFORT);
                break;
            case ChatPhase.ASSESSMENT_TECH_COMFORT:
                userDataRef.current.techComfort = text;
                setChatPhase(ChatPhase.ASSESSMENT_STRENGTH);
                break;
            case ChatPhase.ASSESSMENT_STRENGTH:
                userDataRef.current.strength = text;
                setChatPhase(ChatPhase.ASSESSMENT_WEAKNESS);
                break;
            case ChatPhase.ASSESSMENT_WEAKNESS:
                userDataRef.current.weakness = text;
                setChatPhase(ChatPhase.ASSESSMENT_INCOME);
                break;
            case ChatPhase.ASSESSMENT_INCOME:
                userDataRef.current.income = text;
                setChatPhase(ChatPhase.ANALYZING);
                break;
        }
    };


    return (
        <main className="h-screen w-screen bg-slate-900 text-white flex flex-col font-sans bg-grid-slate-800/[0.2] relative">
            <div className="absolute pointer-events-none inset-0 flex items-center justify-center bg-slate-900 [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)]"></div>
            <header className="p-4 text-center border-b border-slate-700 bg-slate-900/80 backdrop-blur-sm z-10">
                <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Real Estate Career Advisor</h1>
            </header>

            <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 z-10">
                {messages.map((msg) => (
                    <ChatMessage key={msg.id} message={msg} />
                ))}
                {isLoading && messages.length > 0 && (
                     <div className="flex items-start gap-3 my-4 animate-fade-in justify-start">
                        <BotIcon className="w-8 h-8 text-indigo-300 flex-shrink-0" />
                        <div className="max-w-md p-4 rounded-2xl bg-indigo-500 text-white rounded-bl-none">
                            <div className="flex items-center gap-2">
                                <span className="w-2 h-2 bg-white rounded-full animate-bounce delay-0"></span>
                                <span className="w-2 h-2 bg-white rounded-full animate-bounce delay-150"></span>
                                <span className="w-2 h-2 bg-white rounded-full animate-bounce delay-300"></span>
                            </div>
                        </div>
                    </div>
                )}
            </div>
            
            <div className="z-10">
                <UserInput onSubmit={handleUserSubmit} isLoading={isLoading || chatPhase === ChatPhase.COMPLETE} />
            </div>
             <style>{`
                .animate-fade-in {
                    animation: fadeIn 0.5s ease-in-out;
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .bg-grid-slate-800\\[\\/0\\.2\\] {
                    background-image: linear-gradient(white 1px, transparent 1px), linear-gradient(to right, white 1px, transparent 1px);
                    background-size: 4rem 4rem;
                    background-position: center center;
                    background-color: rgb(15 23 42);
                    opacity: 0.2;
                    position: absolute;
                    inset: 0;
                    height: 100%;
                    width: 100%;
                }
            `}</style>
        </main>
    );
};

export default App;